# Market Brief site (GitHub Pages / 사내 웹서버용)

폴더 구조
- /daily/index.html  -> 데일리 페이지 URL: .../daily/
- /weekly/index.html -> 주간 페이지 URL: .../weekly/

GitHub Pages 업로드(웹 UI)
1) 저장소 화면 → Add file → Upload files
2) PC에서 'market-brief-site' 폴더를 통째로 드래그 앤 드롭
3) Commit changes → Settings → Pages에서 Source=main/root 확인
4) 1~2분 후 .../daily/ , .../weekly/ 로 접속

사내 서버(IIS/Nginx)는 /daily, /weekly 폴더 그대로 복사 배포하면 됩니다.
